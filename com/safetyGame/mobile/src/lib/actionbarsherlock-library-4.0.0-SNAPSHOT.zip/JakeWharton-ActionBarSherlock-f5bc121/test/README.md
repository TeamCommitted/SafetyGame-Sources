ActionBarSherlock Test
======================

This folder contains two applications which perform unit testing against the
main library.

 * `app/` - Individual activities which each set up and provide interaction
   methods for a specific test case.

 * `runner/` - Suite of test cases that verify each activity and method
   provided by `app/` are operating as expected.
