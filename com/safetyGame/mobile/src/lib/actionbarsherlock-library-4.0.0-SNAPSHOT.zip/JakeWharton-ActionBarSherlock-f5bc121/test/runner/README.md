ActionBarSherlock Test Runner
=============================

Suite of test cases that verify each activity and method provided by the test
app are operating as expected.

Each class has a name which provides insight into the what it is testing and is
then prefixed by `Test`. If you are providing new test cases please follow the
same naming conventions that are already in use. If the test cases corresponds
to an activity in the test app please ensure that you use the same name for
both classes.
